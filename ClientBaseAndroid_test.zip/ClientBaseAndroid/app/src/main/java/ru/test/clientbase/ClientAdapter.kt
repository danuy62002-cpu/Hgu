package ru.test.clientbase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ClientAdapter(
    private val onDelete: (Client) -> Unit
) : RecyclerView.Adapter<ClientAdapter.VH>() {

    private var items: List<Client> = emptyList()

    fun submitList(list: List<Client>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_client, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.name.text = item.fullName
        holder.phone.text = item.phone
        holder.delete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount() = items.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.name)
        val phone: TextView = v.findViewById(R.id.phone)
        val delete: Button = v.findViewById(R.id.deleteButton)
    }
}
