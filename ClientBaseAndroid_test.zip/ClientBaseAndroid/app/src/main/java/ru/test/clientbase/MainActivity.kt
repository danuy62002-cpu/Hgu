package ru.test.clientbase

import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var userStore: UserStore
    private lateinit var adapter: ClientAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.get(this)
        userStore = UserStore(this)

        val authPanel = findViewById<LinearLayout>(R.id.authPanel)
        val clientsPanel = findViewById<LinearLayout>(R.id.clientsPanel)
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val userLabel = findViewById<android.widget.TextView>(R.id.userLabel)

        adapter = ClientAdapter { client ->
            lifecycleScope.launch { db.clientDao().delete(client) }
        }

        findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.clientList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<android.widget.Button>(R.id.registerButton).setOnClickListener {
            val ok = userStore.register(username.text.toString().trim(), password.text.toString())
            Toast.makeText(
                this,
                if (ok) "Регистрация выполнена" else "Не удалось зарегистрировать: проверьте данные или пользователь уже создан",
                Toast.LENGTH_LONG
            ).show()
        }

        findViewById<android.widget.Button>(R.id.loginButton).setOnClickListener {
            if (userStore.login(username.text.toString().trim(), password.text.toString())) {
                authPanel.visibility = android.view.View.GONE
                clientsPanel.visibility = android.view.View.VISIBLE
                userLabel.text = "Пользователь: ${username.text.toString().trim()}"
                observeClients()
            } else {
                Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<android.widget.Button>(R.id.addButton).setOnClickListener {
            showAddClientDialog()
        }
    }

    private fun observeClients() {
        lifecycleScope.launch {
            db.clientDao().observeAll().collect { adapter.submitList(it) }
        }
    }

    private fun showAddClientDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }

        val name = EditText(this).apply {
            hint = "ФИО"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }

        val phone = EditText(this).apply {
            hint = "Телефон"
            inputType = InputType.TYPE_CLASS_PHONE
            setText("+7")
            setSelection(length())
            filters = arrayOf(InputFilter { source, _, _, _, _, _ ->
                source.filter { it.isDigit() || it == '+' || it == ' ' || it == '-' || it == '(' || it == ')' }
            })
        }

        box.addView(name)
        box.addView(phone)

        AlertDialog.Builder(this)
            .setTitle("Новый клиент")
            .setView(box)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Добавить") { _, _ ->
                val fullName = name.text.toString().trim()
                var rawPhone = phone.text.toString().trim()
                if (!rawPhone.startsWith("+7")) rawPhone = "+7" + rawPhone.removePrefix("+")
                if (fullName.isBlank() || rawPhone.length < 4) {
                    Toast.makeText(this, "Введите ФИО и телефон", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch {
                    db.clientDao().insert(Client(fullName = fullName, phone = rawPhone))
                }
            }
            .show()
    }
}
