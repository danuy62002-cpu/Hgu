package ru.test.clientbase

import android.content.Context

class UserStore(context: Context) {
    private val prefs = context.getSharedPreferences("user", Context.MODE_PRIVATE)

    fun register(login: String, password: String): Boolean {
        if (login.isBlank() || password.isBlank()) return false
        if (prefs.contains("login")) return false
        prefs.edit().putString("login", login).putString("password", password).apply()
        return true
    }

    fun login(login: String, password: String): Boolean =
        login == prefs.getString("login", null) &&
        password == prefs.getString("password", null)

    fun registered(): Boolean = prefs.contains("login")
}
