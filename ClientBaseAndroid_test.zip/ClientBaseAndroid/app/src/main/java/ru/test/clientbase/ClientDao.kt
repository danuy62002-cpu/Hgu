package ru.test.clientbase

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("SELECT * FROM clients ORDER BY fullName COLLATE NOCASE")
    fun observeAll(): Flow<List<Client>>

    @Insert
    suspend fun insert(client: Client)

    @Delete
    suspend fun delete(client: Client)
}
